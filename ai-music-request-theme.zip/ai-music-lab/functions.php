<?php
// セッション開始（GETが消えても request 内容を保持するため）
add_action('init', function () {
  if (!session_id()) {
    session_start();
  }
});

function aimusiclab_enqueue_assets() {
  $uri = get_template_directory_uri();

  // テーマ直下の style.css を読む
  wp_enqueue_style('aimusiclab-style', get_stylesheet_uri(), array(), '1.0');

  // トップページだけ bubbles.js を読む
  if ( is_front_page() ) {
    wp_enqueue_script(
      'aimusiclab-bubbles',
      $uri . '/assets/js/bubbles.js',
      array(),
      '1.0',
      true
    );
  }
}
add_action('wp_enqueue_scripts', 'aimusiclab_enqueue_assets');

// request / result ページに body クラスを付与
add_filter('body_class', function($classes){
  if (is_page('request')) $classes[] = 'page-request';
  if (is_page('result'))  $classes[] = 'page-result';
  return $classes;
});
