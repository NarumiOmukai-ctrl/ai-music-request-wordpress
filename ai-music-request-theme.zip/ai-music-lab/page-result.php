<?php
/* AI Music Lab Result Template */
get_header();

// 翻訳マップ関数
function get_translated_value( $key, $value ) {
  $translations = array(
    'genre' => array(
      '' => 'おまかせ',
      'jpop' => 'J-POP',
      'ballad' => 'バラード',
      'rock' => 'ロック',
      'dance' => 'ダンス / EDM',
      'anime' => 'アニソン風',
      'acoustic' => 'アコースティック / ピアノ中心',
    ),
    'tempo' => array(
      '' => 'おまかせ',
      'slow' => 'ゆっくりめ',
      'medium' => 'ふつう',
      'fast' => 'はやめ',
    ),
    'mood' => array(
      'bright' => '明るい / 前向き',
      'sad' => 'しっとり / 切ない',
      'cool' => 'クール / かっこいい',
      'cute' => 'かわいい',
      'relax' => 'ゆったり / リラックス',
    ),
    'instrument' => array(
      'piano' => 'ピアノ',
      'guitar' => 'ギター',
      'strings' => 'ストリングス',
      'synth' => 'シンセサイザー',
      'drums' => 'ドラム',
      'vocal' => 'コーラス / ハモり',
    ),
    'lyrics_lang' => array(
      'ja' => '日本語メイン',
      'en' => '英語メイン',
      'mix' => '日英ミックス',
      'none' => '歌詞なし（インスト）',
    ),
  );

  if ( isset( $translations[$key][$value] ) ) {
    return $translations[$key][$value];
  }
  return $value;
}
?>

<main class="request-main" style="max-width: 960px; margin: 40px auto; padding: 0 20px;">

  <!-- 画面タイトルとリード文 -->
  <header style="margin-bottom: 24px;">
    <h1 style="font-size: 1.8rem; margin-bottom: 8px;">🪗うたっく🎷が曲を作ってみたよ🎸🎧</h1>
    <p style="font-size: 1.0rem; color: #000;">
      リクエスト内容と条件をもとに、曲を作りました🎵<br>
      気に入った曲があれば「いいね！」👍を押して選択、修正したい場合は「修正してみる」🤔を押してください 。
    </p>
  </header>

  <!-- ① 依頼内容のまとめ表示 -->
  <section style="margin-bottom: 24px;">
    <h2 style="font-size: 1.1rem; margin-bottom: 8px;">① 依頼内容のまとめ</h2>
    <div style="background:#fff;border-radius:12px;padding:14px 16px;border:1px solid #e2e2f0;font-size:0.95rem;">
      <p style="margin: 4px 0;">
        <strong>リクエスト内容：</strong>
        <span id="summary-request">
          <?php echo esc_html($_GET['base_request'] ?? ''); ?>
        </span>
      </p>
      <p style="margin: 4px 0;">
        <strong>ジャンル：</strong>
        <span id="summary-genre">
          <?php echo esc_html( get_translated_value( 'genre', $_GET['genre'] ?? '' ) ); ?>
        </span>
      </p>
      <p style="margin: 4px 0;">
        <strong>テンポ：</strong>
        <span id="summary-tempo">
          <?php echo esc_html( get_translated_value( 'tempo', $_GET['tempo'] ?? '' ) ); ?>
        </span>
      </p>
      <p style="margin: 4px 0;">
        <strong>雰囲気：</strong>
        <span id="summary-mood">
          <?php
          $moods = (array)($_GET['mood'] ?? []);
          $translated_moods = array_map( function($m) { return get_translated_value('mood', $m); }, $moods );
          echo esc_html( implode(', ', $translated_moods) );
          ?>
        </span>
      </p>
      <p style="margin: 4px 0;">
        <strong>目立たせたい楽器：</strong>
        <span id="summary-instrument">
          <?php
          $inst = (array)($_GET['instrument'] ?? []);
          $translated_inst = array_map( function($i) { return get_translated_value('instrument', $i); }, $inst );
          echo esc_html( implode(', ', $translated_inst) );
          ?>

        </span>
      </p>
      <p style="margin: 4px 0;">
        <strong>歌詞の言語：</strong>
        <span id="summary-lyrics-lang">
          <?php echo esc_html( get_translated_value( 'lyrics_lang', $_GET['lyrics_lang'] ?? '' ) ); ?>
        </span>
      </p>
      <p style="margin: 4px 0;">
        <strong>自由記入：</strong>
        <span id="summary-detail">
          <?php echo esc_html($_GET['detail'] ?? ''); ?>
        </span>
      </p>
    </div>
  </section>

  <!-- ② 曲プレビュー（デモ音源 + 音符アニメーション） -->
  <section style="margin-bottom: 32px;">
    <h2 style="font-size: 1.1rem; margin-bottom: 8px;">
      ② 生成された曲（<span id="take-label">１曲目</span>）
    </h2>
    <p style="font-size: 0.9rem;color:#000;margin-bottom:8px;">
      <strong><span id="remaining-count"></span>曲目</strong>（最大3曲まで）
    </p>

    <div style="background:#fff;border-radius:12px;padding:18px 18px 40px;border:1px solid #e0e0e0;position:relative;overflow:hidden;min-height:120px;">
      <!-- 音符アニメーションを流すコンテナ -->
      <div id="animation-container" style="position:absolute;top:0;right:0;width:100%;height:100%;pointer-events:none;"></div>
      
      <!-- 実際のプレイヤー・ボタン類 -->
      <div style="position:relative;z-index:1;">
          <audio id="audio-player" controls preload="metadata" style="width:100%; margin-bottom:12px;">
          </audio>

          <p id="demo-note" style="font-size:0.8rem;color:#666;margin:0;">
            ※現在はデモ音源を再生しています。
          </p>  

        <!-- 「いいね！」「修正してみる」ボタン -->
        <div style="margin-top:18px; display:flex; flex-wrap:wrap; gap:12px; justify-content:flex-start; align-items:center;">
          <button id="btn-accept"
                  type="button"
                  class="bubble"
                  style="padding:10px 20px;border-radius:999px;border:none;cursor:pointer;
                         background:#f732cc;color:#fff;font-weight:600;font-size:0.9rem;">
            いいね！
          </button>
          <button id="btn-revise"
                  type="button"
                  class="bubble"
                  style="padding:10px 20px;border-radius:999px;border:none;cursor:pointer;
                         background:#5a3ff3d8;color:#fff;font-weight:600;font-size:0.9rem;">
            修正してみる
          </button>
        </div>

        <!-- 修正内容入力欄（「修正してみる」押下時に開く） -->
        <div id="revise-box" style="margin-top:16px; display:none;">
          <label for="revise-text"
                 style="display:block;font-weight:600;margin-bottom:4px;font-size:0.9rem;">
            どのように修正したいですか？
          </label>
          <textarea id="revise-text" rows="4"
                    placeholder="例）サビをもっと盛り上げてほしい／テンポを少しゆっくりに／ピアノを目立たせたい、など"
                    style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid #ccc;font-size:0.9rem;"></textarea>
          <button id="btn-send-revise"
                  type="button"
                  class="bubble"
                  style="margin-top:8px;padding:8px 16px;border-radius:999px;border:none;cursor:pointer;
                         background:#ff8b2f;color:#fff;font-weight:600;font-size:0.9rem;">
            この内容で作り直す
          </button>
          <p style="font-size:0.8rem;color:#666;margin-top:4px;">
            ※最大3回まで作り直しできます。
          </p>
        </div>
      </div>
    </div>
  </section>

  <!-- ③ 生成された最大3曲の中から選択するセクション -->
  <section id="select-section" style="margin-bottom:32px; display:none;">
    <h2 style="font-size:1.1rem; margin-bottom:8px;">③ どの曲をダウンロードしますか？（最大3曲まで）</h2>
    <p style="font-size:0.9rem;color:#000;margin-bottom:8px;">
      これまでに作成したバージョンの中から、欲しい曲を選んでください。<br>
      1曲あたり <strong>100円</strong> でダウンロードできます。
    </p>

    <div id="track-list"
         style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;"></div>

    <p id="selection-summary"
       style="margin-top:12px;font-size:0.95rem;font-weight:600;color:#333;">
      選択中：0曲 / 合計 0円
    </p>

    <button id="btn-purchase"
            type="button"
            class="bubble"
            style="margin-top:8px;padding:10px 20px;border-radius:999px;border:none;cursor:pointer;
                   background:#4c6fff;color:#fff;font-weight:600;font-size:0.95rem;">
      この内容で購入手続きへ
    </button>
  </section>

  <!-- 条件入力画面（request.html）へ戻るボタン -->
  <section style="margin-bottom:32px;">
    <p class="bubble" style="margin-top: 8px; text-align: center;">
      <button id="btn-back" class="back-link"
              style="font-size: 0.8rem; text-decoration: none; color: #2e07db; background: none; border: none; cursor: pointer; padding: 0; display: inline-block;">
        🔙 条件入力画面に戻る
      </button>
    </p>
  </section>

</main>

<?php
$theme_uri = get_template_directory_uri();
$demo_tracks = array(
  $theme_uri . '/assets/audio/nukumori.mp3',
  $theme_uri . '/assets/audio/kome-paradise.mp3',
  $theme_uri . '/assets/audio/kakusei.mp3',
);
$demo_notes = array(
  '（冬になると恋しくなるよね🥹⇒ 「ぬくもりの中で」）',
  '（妻に「何が好き？」と聞いてみた衝撃の答え⇒「🍚米パラダイス」）',
  '（「パパ、保存って何のマーク？」😱⇒「隔世の感」）',
);
?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  // ===== フォームからのパラメータを取得 =====
  const params = new URLSearchParams(location.search);

  const baseRequest = params.get('base_request') || '';
  const genre = params.get('genre') || '';
  const tempo = params.get('tempo') || '';
  const detail = params.get('detail') || '';
  const lyricsLang = params.get('lyrics_lang') || '';
  
  // mood と mood[] の両方に対応
  let moods = params.getAll('mood');
  if (!moods || moods.length === 0) {
    audiomoods = params.getAll('mood[]') || [];
  }
  
  // instrument と instrument[] の両方に対応
  let instruments = params.getAll('instrument');
  if (!instruments || instruments.length === 0) {
    instruments = params.getAll('instrument[]') || [];
  }

  // ===== 曲生成まわり（デモ） =====
  const MAX_TAKES = 3;
  let currentTake = 1;

  const takeLabel = document.getElementById('take-label');
  const remainingCount = document.getElementById('remaining-count');
  const audioPlayer = document.getElementById('audio-player');

  const demoTracks = <?php echo wp_json_encode($demo_tracks); ?>;
  const demoNotes  = <?php echo wp_json_encode($demo_notes); ?>;

  // 作られた案を保存（最後に並べて表示する用）
  const generatedTracks = [];

  // セレクション表示用
  const selectSection = document.getElementById('select-section');
  const trackList = document.getElementById('track-list');
  const selectionSummary = document.getElementById('selection-summary');
  const btnPurchase = document.getElementById('btn-purchase');

  function updateTakeDisplay() {
    takeLabel.textContent = `${currentTake}曲目`;
    remainingCount.textContent = currentTake;

    const src = demoTracks[currentTake - 1] || demoTracks[0];
    audioPlayer.src = src;
    audioPlayer.load();

    // 注釈を更新
    const demoNoteElement = document.getElementById('demo-note');
    if (demoNoteElement) {
      demoNoteElement.textContent = `※現在はデモ音源を再生しています。${demoNotes[currentTake - 1] || demoNotes[0]}`;
    }

    generatedTracks[currentTake - 1] = {
      label: `${currentTake}曲目`,
      src: src
    };

    // 1案目から常に一覧を更新（最大3曲）
    showSelectSection();
  }

  // 音楽アニメーション開始
  let animationIds = [];
  let isAnimating = false;
  let imageIndex = 0;

  function startMusicAnimation() {
    const container = document.getElementById('animation-container');
    
    // 既存のアニメーションをクリア
    if (isAnimating) {
      isAnimating = false;
      animationIds.forEach(id => clearTimeout(id));
      animationIds = [];
      container.innerHTML = '';
    }
    
    animationIds = [];
    isAnimating = true;
    imageIndex = 0;
    
    const ANIMATION_DURATION = 25000; // 25秒
    const SPAWN_INTERVAL = 1500; // 新しい画像を1.5秒ごとに生成
    const TOTAL_IMAGES = 16; // 画像は16枚（1〜16）

    // 1.5秒ごとに新しい画像を生成（パレードのように連続）
    const spawnNextImage = () => {
      // アニメーションが無効化されている、または音声が停止している場合は中止
      if (!isAnimating || audioPlayer.paused || audioPlayer.ended) {
        return;
      }

      // 16枚の画像を順番に使用（ループ）
      const imageNumber = (imageIndex % TOTAL_IMAGES) + 1;
      const img = document.createElement('img');
      img.src = `<?php echo get_template_directory_uri(); ?>/assets/images/music-corps-${imageNumber}.png`;
      img.className = 'music-corps';
      img.style.height = '60px';
      img.style.width = 'auto';
      container.appendChild(img);
      
      imageIndex++;

      // 25秒後に削除
      const removeId = setTimeout(() => {
        if (img.parentNode) {
          img.remove();
        }
      }, ANIMATION_DURATION);
      animationIds.push(removeId);

      // 1.5秒後に次の画像をスポーン
      const spawnId = setTimeout(() => {
        spawnNextImage();
      }, SPAWN_INTERVAL);
      animationIds.push(spawnId);
    };

    // 最初の画像をすぐに生成
    spawnNextImage();

    // 再生終了時にクリア
    const endHandler = () => {
      isAnimating = false;
      animationIds.forEach(id => clearTimeout(id));
      animationIds = [];
      container.innerHTML = '';
    };
    
    audioPlayer.removeEventListener('ended', endHandler);
    audioPlayer.addEventListener('ended', endHandler);
  }

  function updateSelectionSummary() {
    const checkboxes = document.querySelectorAll('.track-checkbox');
    let count = 0;
    checkboxes.forEach(cb => {
      if (cb.checked) count++;
    });
    const total = count * 100;
    selectionSummary.textContent = `選択中：${count}曲 / 合計 ${total}円`;
  }

  function showSelectSection() {
    if (!generatedTracks.length) return;

    selectSection.style.display = 'block';
    trackList.innerHTML = '';

    // グローバルなcheckStatesか、現在のDOM状態からチェック状態を取得
    let checkStates = window.checkStates || {};
    if (!window.checkStates) {
      const existingCheckboxes = document.querySelectorAll('.track-checkbox');
      existingCheckboxes.forEach(cb => {
        const index = cb.dataset.index;
        checkStates[index] = cb.checked;
      });
    }

    generatedTracks.forEach((track, index) => {
      if (!track) return;
      const card = document.createElement('div');
      card.style.background = '#fff';
      card.style.borderRadius = '12px';
      card.style.padding = '12px 14px';
      card.style.border = '1px solid #e0e0e0';

      const checkboxId = `select-track-${index}`;
      const isChecked = checkStates[index] ? 'checked' : '';

      card.innerHTML = `
        <p style="font-weight:600;margin:0 0 6px;">${track.label}</p>
        <audio controls style="width:100%;margin-bottom:8px;">
          <source src="${track.src}">
        </audio>
        <label for="${checkboxId}"
               style="font-size:0.85rem;display:flex;align-items:center;gap:6px;">
          <input type="checkbox" id="${checkboxId}" class="track-checkbox" data-index="${index}" ${isChecked}>
          この曲を選ぶ（100円）
        </label>
      `;
      trackList.appendChild(card);
    });

    // チェックボックスにイベントを付与
    const checkboxes = document.querySelectorAll('.track-checkbox');
    checkboxes.forEach(cb => {
      cb.addEventListener('change', updateSelectionSummary);
    });

    updateSelectionSummary();
  }

  // 初回表示（１曲目）
  updateTakeDisplay();

  // オーディオプレイヤーのイベントリスナー
  audioPlayer.addEventListener('play', () => {
    startMusicAnimation();
  });

  audioPlayer.addEventListener('pause', () => {
    const container = document.getElementById('animation-container');
    container.innerHTML = '';
  });

  // ===== ボタン類の動き =====
  const btnAccept = document.getElementById('btn-accept');
  const btnRevise = document.getElementById('btn-revise');
  const reviseBox = document.getElementById('revise-box');
  const btnSendRevise = document.getElementById('btn-send-revise');
  const reviseText = document.getElementById('revise-text');

  btnAccept.addEventListener('click', () => {
    // 現在の案のチェックボックスをチェック
    const currentCheckboxId = `select-track-${currentTake - 1}`;
    const checkbox = document.getElementById(currentCheckboxId);
    if (checkbox) {
      checkbox.checked = true;
      updateSelectionSummary();
    }
  });

  btnRevise.addEventListener('click', () => {
    if (currentTake >= MAX_TAKES) {
      alert('作り直しは3回までです。下の一覧から、欲しい曲を選んでください。');
      return;
    }
    reviseBox.style.display = 'block';
    reviseText.focus();
  });

  btnSendRevise.addEventListener('click', () => {
    if (!reviseText.value.trim()) {
      if (!confirm('修正内容が空ですが、このまま作り直しますか？')) {
        return;
      }
    }

    // ★ 修正前にチェック状態を保存
    const checkStates = {};
    const existingCheckboxes = document.querySelectorAll('.track-checkbox');
    existingCheckboxes.forEach(cb => {
      const index = cb.dataset.index;
      checkStates[index] = cb.checked;
    });
    window.checkStates = checkStates;

    currentTake++;
    reviseBox.style.display = 'none';
    reviseText.value = '';

    // デモでは単に別の demoTracks に切り替える
    updateTakeDisplay();
  });

  // 購入ボタン
  btnPurchase.addEventListener('click', () => {
    const checkboxes = document.querySelectorAll('.track-checkbox');
    const selectedIndexes = [];
    checkboxes.forEach(cb => {
      if (cb.checked) selectedIndexes.push(Number(cb.dataset.index) + 1);
    });

    if (!selectedIndexes.length) {
      alert('まだ曲が選択されていません。購入したい曲のチェックボックスをオンにしてください。');
      return;
    }

    const count = selectedIndexes.length;
    const total = count * 100;
    alert(
      `${selectedIndexes.map(idx => `${idx}曲目`).join('・')}が選択されました。\n` +
      `合計 ${total}円 （1曲 100円 × ${count}曲）\n\n` +
      '※ デモ版です。本番ではここから決済画面に進む想定です。'
    );
  });

  // 条件入力画面に戻るボタン
  const btnBack = document.getElementById('btn-back');
  btnBack.addEventListener('click', () => {
    const confirmed = confirm('作成された曲は削除されます。よろしいですか？');
    if (!confirmed) {
      return;
    }

    // 「はい」を選んだ場合、現在の条件をURLパラメータで保持してrequestへ戻る
    const queryParams = new URLSearchParams();
    queryParams.set('message', baseRequest);
    queryParams.set('base_request', baseRequest);
    queryParams.set('genre', genre);
    queryParams.set('tempo', tempo);
    queryParams.set('lyrics_lang', lyricsLang);
    queryParams.set('detail', detail);

    // 複数値のパラメータ（mood, instrument）を追加
    moods.forEach(mood => {
      queryParams.append('mood', mood);
    });
    instruments.forEach(instrument => {
      queryParams.append('instrument', instrument);
    });

    // request へリダイレクト
    window.location.href = `<?php echo esc_url(home_url('/request/')); ?>?${queryParams.toString()}`;
  });
});
</script>

<?php get_footer(); ?>
