<footer class="site-footer">
  <small>© 2025 AI楽曲ラボ / 制作：大向なるみ（ジョブトレ制作課題）</small>
</footer>

<?php wp_footer(); ?>
</body>
</html>
