<?php
if (strpos($_SERVER['REQUEST_URI'], '/index') === 0) {
  wp_safe_redirect(home_url('/'));
  exit;
}
?>

<?php
/* AI Music Lab Main Template */
get_header();
?>

  <!-- 男女＋吹き出し -->
  <header class="hero">
    <div class="hero-inner">

      <!-- 左側の吹き出し群 -->
      <button class="bubble bubble-left bubble-1"
              data-message="〇〇で使う曲を作って（例：ダンスコンクール、結婚式、卒園式、カラオケなど）"
              aria-label="〇〇で使う曲を作って（例：ダンスコンクール、結婚式、卒園式、カラオケなど）のリクエストを送る">
        〇〇で使う曲を作って<br>（例：ダンスコンペ、結婚式、卒園式、カラオケ、学園祭など）
      </button>

      <button class="bubble bubble-left bubble-2"
              data-message="テスト前なのに頭に入らないから曲にして！"
              aria-label="テスト前なのに頭に入らないから曲にして！のリクエストを送る">
        テスト前なのに<br>頭に入らないから曲にして！
      </button>

      <button class="bubble bubble-left bubble-3"
              data-message="あの人に自分の気持ちを伝えたい（歌詞：おまかせ or 自作）"
              aria-label="あの人に自分の気持ちを伝えたい（歌詞：おまかせ or 自作）のリクエストを送る">
        あの人に自分の気持ちを伝えたい
      </button>

      <!-- 右側の吹き出し群 -->
      <button class="bubble bubble-right bubble-4"
              data-message="仕事や勉強に集中できる曲を作って"
              aria-label="仕事や勉強に集中できる曲を作ってのリクエストを送る">
        仕事や勉強に<br>集中できる曲を作って
      </button>

      <button class="bubble bubble-right bubble-5"
              data-message="今の気分を笑い飛ばして！"
              aria-label="今の気分を笑い飛ばして！のリクエストを送る">
        今の気分を笑い飛ばして！
      </button>

      <button class="bubble bubble-right bubble-6"
              data-message="自分で歌詞を作るから、曲にして"
              aria-label="自分で歌詞を作るから、曲にしてのリクエストを送る">
        自分で歌詞を作るから、曲にして
      </button>

      <!-- 画像：ここはすでにOK -->
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/hero-couple.png"
           alt="音楽のアイデアを考えている男女"
           class="hero-image">
    </div>
  </header>


  <main>

    <!--
      ■ サービスの流れ（フローチャート風）
        - 5つのSTEPで、利用の流れを視覚的に説明
    -->
    <section class="flow">
      <div class="flow-inner">

        <h2 class="flow-title">楽曲作成サービスの流れ</h2>
        <p class="flow-lead">
          🎵上の吹き出しをクリックして、あなたの「今」の気持ちにぴったりな曲を作りましょう🎵
        </p>

        <!-- 利用イメージを伝える写真（PCでは横並び） -->
        <div class="flow-images">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/troubled-person.png"
              alt="悩める人のイメージ画像"
              class="flow-img">

          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/music-fairies.png"
              alt="ピアノに集まる妖精たちのイメージ画像"
              class="flow-img">

          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/melody.png"
              alt="曲を聴く人のイメージ画像"
              class="flow-img">
        </div>

        <!-- 利用手順を示すフローチャート（STEP1〜5） -->
        <ol class="flow-steps">
          <li class="flow-step">
            <h4>STEP 1</h4>
            <p>曲のイメージを選ぶ<br>（トップページの吹き出しをクリック）</p>
            <div class="flow-emoji">🤔</div>
          </li>
          <li class="flow-step">
            <h4>STEP 2</h4>
            <p>曲の雰囲気、<br>テンポを選択</p>
            <div class="flow-emoji">🧐</div>
          </li>
          <li class="flow-step">
            <h4>STEP 3</h4>
            <p>キーワードを入力<br>（例：フリーワード）<br>🍀自分で考えた<br>歌詞もモチOK!</p>
            <div class="flow-emoji">🥰</div>
          </li>
          <li class="flow-step">
            <h4>STEP 4</h4>
            <p>🎵楽曲を生成🎵<br>少々お待ちください。</p>
            <div class="flow-emoji">🎼🖥️🛜</div>
          </li>
          <li class="flow-step">
            <h4>STEP 5</h4>
            <p>3回まで作り直しOK! <br>気に入った曲をダウンロードしてください。<br>（￥100/曲）</p>
            <div class="flow-emoji">🎤🎧🎵</div>
          </li>
        </ol>

      </div>
    </section>

    <!--
      ■ 楽曲制作例
        - YouTube 埋め込みで、実際に作った曲のイメージを紹介
    -->
    <section class="samples">
      <div class="samples-inner">
        <h2 class="samples-title">楽曲制作例</h2>
        <p class="samples-lead">
          このサイトで作成した曲をもとに、YouTube動画を作成しました（サンプル）。
        </p>

        <div class="sample-list">

          <!-- 平安列伝：歴史勉強ソングのサンプル -->
          <article class="sample">
            <h3 class="sample-title">平安列伝🔥</h3>
            <p class="sample-tag">歴史の試験勉強用</p>
            <p class="sample-desc">
              平安時代の要暗記キーワードを盛り込んだ、一夜漬けソング (^^♪
            </p>
            <div class="sample-player">
              <iframe
                src="https://www.youtube.com/embed/bMWm2Zq7jns"
                title="平安列伝"
                width="100%"
                height="215"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen
              ></iframe>
            </div>
          </article>

          <!-- 働いて働いて…：応援ソングのサンプル -->
          <article class="sample">
            <h3 class="sample-title">働いて働いて働いて働いて働いてまいります！💪</h3>
            <p class="sample-tag">2025年の「新語・流行語大賞」</p>
            <p class="sample-desc">
              忙しい毎日を笑い飛ばそう！
            </p>
            <div class="sample-player">
              <iframe
                src="https://www.youtube.com/embed/QbsYJrLYI1g"
                title="働いて働いて働いて働いて働いてまいります！"
                width="100%"
                height="215"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen
              ></iframe>
            </div>
          </article>

        </div>
      </div>
    </section>

  </main>

<script src="<?php echo get_template_directory_uri(); ?>/assets/js/bubbles.js"></script>
<?php get_footer(); ?>
