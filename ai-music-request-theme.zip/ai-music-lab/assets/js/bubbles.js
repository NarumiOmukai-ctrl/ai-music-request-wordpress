// bubbles.js
document.addEventListener('DOMContentLoaded', () => {
  const bubbles = document.querySelectorAll('.bubble[data-message]'); 

  bubbles.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const msg = btn.dataset.message || '';
      if (!msg) return;

      // 例：/request/ に渡す
      const url = new URL('/request/', window.location.origin);
      url.searchParams.set('msg', msg);
      window.location.href = url.toString();
    });
  });
});
