<?php
/* AI Music Lab request Template */
get_header();
?>

<?php
if (!empty($_GET['msg'])) {
  $incoming = (string) $_GET['msg'];
  $prev     = (string) ($_SESSION['base_request'] ?? '');

  // msg が変わった＝新しい依頼開始 → ②をリセット
  if ($incoming !== $prev) {
    unset($_SESSION['aimusiclab_state']);
  }
}
?>

<?php
// ①リクエスト内容を復元
$base_request = '';
if (!empty($_GET['msg'])) {
  $base_request = (string) $_GET['msg'];
} elseif (!empty($_GET['base_request'])) {
  $base_request = (string) $_GET['base_request'];
} elseif (!empty($_SESSION['base_request'])) {
  $base_request = (string) $_SESSION['base_request'];
}
if ($base_request !== '') {
  $_SESSION['base_request'] = $base_request;
}
?>

<?php
// ②フォーム内容（GETがあれば優先してSESSIONへ保存 / 無ければSESSIONから復元）
$defaults = array(
  'genre' => '',
  'tempo' => '',
  'lyrics_lang' => 'ja',
  'detail' => '',
  'mood' => array(),
  'instrument' => array(),
);

$state = $defaults;

// 「②の値が来ているか」を判定（msg/base_request は除外）
$has_form_params =
  array_key_exists('genre', $_GET) ||
  array_key_exists('tempo', $_GET) ||
  array_key_exists('lyrics_lang', $_GET) ||
  array_key_exists('detail', $_GET) ||
  array_key_exists('mood', $_GET) ||
  array_key_exists('instrument', $_GET);

// まず SESSION から既存の値を復元
if (!empty($_SESSION['aimusiclab_state']) && is_array($_SESSION['aimusiclab_state'])) {
  $state = array_merge($defaults, $_SESSION['aimusiclab_state']);
}

// その後、$_GET から来た値で上書き
if ($has_form_params) {
  // genre, tempo, lyrics_lang, detail は文字列
  if (array_key_exists('genre', $_GET)) {
    $state['genre'] = (string)($_GET['genre'] ?? '');
  }
  if (array_key_exists('tempo', $_GET)) {
    $state['tempo'] = (string)($_GET['tempo'] ?? '');
  }
  if (array_key_exists('lyrics_lang', $_GET)) {
    $state['lyrics_lang'] = (string)($_GET['lyrics_lang'] ?? 'ja');
  }
  if (array_key_exists('detail', $_GET)) {
    $state['detail'] = (string)($_GET['detail'] ?? '');
  }
  
  // mood: URLパラメータで複数値が来る
  if (array_key_exists('mood', $_GET)) {
    $mood_values = (array)$_GET['mood'];
    $state['mood'] = array_filter($mood_values); // 空値を除外
  }
  
  // instrument: URLパラメータで複数値が来る
  if (array_key_exists('instrument', $_GET)) {
    $instrument_values = (array)$_GET['instrument'];
    $state['instrument'] = array_filter($instrument_values); // 空値を除外
  }

  $_SESSION['aimusiclab_state'] = $state;
}
?>

<main class="request-main">
  <style>
    .request-main {
      max-width: 960px;
      margin: 40px auto;
      padding: 0 20px;
    }
  </style>
  <!--
    ■ ページタイトルとリード文
      - index.html で吹き出しをクリックしたあとに表示される、
        楽曲リクエスト用の入力フォームページ
  -->
  <header class="request-header" style="margin-bottom: 24px;">
    <h1 style="font-size: 1.8rem; margin-bottom: 8px;">あなたのご希望の曲</h1>
    <p style="color: #000000; font-size: 1.0rem;">
      あなたが選んだリクエスト内容です😊<br>
      ジャンル・テンポ・楽器などの条件を教えてね👇
    </p>
  </header>

  <!--
    ■ 選択したリクエスト内容の表示カード
      - index.html の吹き出し（data-message）から渡された内容を表示
  -->
  <section aria-label="選択したリクエスト" style="margin-bottom: 32px;">
    <h2 style="font-size: 1.1rem; margin-bottom: 8px;">① あなたのリクエスト内容</h2>

    <div class="selected-message-card"
         style="background: #ffffff; border-radius: 12px; padding: 16px 18px; border: 1px solid #e2e2f0;">
      <p id="selected-message" aria-live="polite"
        style="font-size: 1.4rem; margin: 0; font-weight: 600; color: #09ce93; font-style: italic;">
        <span style="margin-right: 8px;">"</span>
        <span id="message-text"><?php echo esc_html($base_request); ?></span>
        <span style="margin-left: 8px;">"</span>
      </p>
      <p id="selected-message-note"
         style="font-size: 0.8rem; margin-top: 8px; color: #161616;">
        ※トップページで選んだ「こんな曲を作りたい」という希望がここに表示されます。
      </p>
    </div>
  </section>

  <!--
    ■ 楽曲の条件指定フォーム
      - result.html に GET で渡し、次のページで確認・プレビューを行う
  -->
  <section aria-label="楽曲の条件指定" style="margin-bottom: 40px;">
    <h2 style="font-size: 1.1rem; margin-bottom: 12px;">② 楽曲の詳しい条件</h2>
    <p id="condition-intro"
       style="font-size: 1.0rem; color: #000000; margin-bottom: 16px;">
      作りたい曲のイメージを教えてね🍀<br>
      まだ決まっていないなら、「おまかせ」と自由記入欄に書いてもOK🤗
    </p>

    <form class="request-form"
          action="/result/"
          method="get"
          autocomplete="off"
          style="background: #ffffff; border-radius: 12px; padding: 20px 18px 30px 18px; border: 1px solid #e0e0e0;">

      <!--
        ベースとなるリクエスト内容
        - index.html の吹き出しテキストを base_request として result.html に渡す
      -->
      <input type="hidden" name="base_request" id="base-request-hidden"
            value="<?php echo esc_attr($base_request); ?>">


      <!-- ジャンル選択 -->
      <div class="form-group" style="margin-bottom: 16px;">
        <label for="genre" style="display: block; font-weight: 600; margin-bottom: 4px;">
          曲のジャンル
        </label>
        <select id="genre" name="genre"
                style="width: 100%; padding: 8px 10px; border-radius: 8px; border: 1px solid #ccc;">
          <option value="">おまかせ</option>
          <option value="jpop" <?php selected($state['genre'] ?? '', 'jpop'); ?>>J-POP</option>
          <option value="ballad" <?php selected($state['genre'], 'ballad'); ?>>バラード</option>
          <option value="rock" <?php selected($state['genre'], 'rock'); ?>>ロック</option>
          <option value="dance" <?php selected($state['genre'], 'dance'); ?>>ダンス / EDM</option>
          <option value="anime" <?php selected($state['genre'], 'anime'); ?>>アニソン風</option>
          <option value="acoustic" <?php selected($state['genre'], 'acoustic'); ?>>アコースティック / ピアノ中心</option>
          <option value="other">その他（自由記入欄に記載）</option>
        </select>
      </div>

      <!-- テンポ（ラジオボタン） -->
      <div class="form-group" style="margin-bottom: 16px;">
        <span style="display: block; font-weight: 600; margin-bottom: 4px;">
          テンポ（速さ）🎼
        </span>
        <div style="display: flex; flex-wrap: wrap; gap: 8px; font-size: 0.9rem;">
          <label><input type="radio" name="tempo" value="slow" <?php checked($state['tempo'] ?? '', 'slow'); ?>> ゆっくりめ</label>
          <label><input type="radio" name="tempo" value="medium" <?php checked($state['tempo'] ?? '', 'medium'); ?>> ふつう</label>
          <label><input type="radio" name="tempo" value="fast" <?php checked($state['tempo'] ?? '', 'fast'); ?>> はやめ</label>
          <label><input type="radio" name="tempo" value="" <?php checked($state['tempo'] ?? '', ''); ?>> おまかせ</label>
        </div>
      </div>

      <!-- ムード（チェックボックス） -->
      <div class="form-group" style="margin-bottom: 16px;">
        <span style="display: block; font-weight: 600; margin-bottom: 4px;">
          雰囲気・ムード（複数選択可）🌿🌺🍃💐🌲
        </span>
        <div style="display: flex; flex-wrap: wrap; gap: 8px; font-size: 0.9rem;">
          <label><input type="checkbox" name="mood[]" value="bright" <?php echo in_array('bright', (array)($state['mood'] ?? []), true) ? 'checked' : ''; ?>> 明るい / 前向き</label>
          <label><input type="checkbox" name="mood[]" value="sad"    <?php echo in_array('sad',    (array)($state['mood'] ?? []), true) ? 'checked' : ''; ?>> しっとり / 切ない</label>
          <label><input type="checkbox" name="mood[]" value="cool"   <?php echo in_array('cool',   (array)($state['mood'] ?? []), true) ? 'checked' : ''; ?>> クール / かっこいい</label>
          <label><input type="checkbox" name="mood[]" value="cute"   <?php echo in_array('cute',   (array)($state['mood'] ?? []), true) ? 'checked' : ''; ?>> かわいい</label>
          <label><input type="checkbox" name="mood[]" value="relax"  <?php echo in_array('relax',  (array)($state['mood'] ?? []), true) ? 'checked' : ''; ?>> ゆったり / リラックス</label>
        </div>
      </div>

      <!-- 使用したい楽器（チェックボックス） -->
      <div class="form-group" style="margin-bottom: 16px;">
        <span style="display: block; font-weight: 600; margin-bottom: 4px;">
          目立たせたい楽器（複数選択可）🪗🪇🪈🥁🎷🎹
        </span>
        <div style="display: flex; flex-wrap: wrap; gap: 8px; font-size: 0.9rem;">
          <label><input type="checkbox" name="instrument[]" value="piano"  <?php echo in_array('piano',  (array)($state['instrument'] ?? []), true) ? 'checked' : ''; ?>> ピアノ</label>
          <label><input type="checkbox" name="instrument[]" value="guitar" <?php echo in_array('guitar', (array)($state['instrument'] ?? []), true) ? 'checked' : ''; ?>> ギター</label>
          <label><input type="checkbox" name="instrument[]" value="strings"<?php echo in_array('strings',(array)($state['instrument'] ?? []), true) ? 'checked' : ''; ?>> ストリングス</label>
          <label><input type="checkbox" name="instrument[]" value="synth"  <?php echo in_array('synth',  (array)($state['instrument'] ?? []), true) ? 'checked' : ''; ?>> シンセサイザー</label>
          <label><input type="checkbox" name="instrument[]" value="drums"  <?php echo in_array('drums',  (array)($state['instrument'] ?? []), true) ? 'checked' : ''; ?>> ドラム</label>
          <label><input type="checkbox" name="instrument[]" value="vocal"  <?php echo in_array('vocal',  (array)($state['instrument'] ?? []), true) ? 'checked' : ''; ?>> コーラス / ハモり</label>
        </div>
      </div>

      <!-- 歌詞の言語 -->
      <div class="form-group" id="lyrics-lang-group" style="margin-bottom: 16px;">
        <span style="display: block; font-weight: 600; margin-bottom: 4px;">
          歌詞の言語 🎤🧑🏻👩
        </span>
        <div style="display: flex; flex-wrap: wrap; gap: 8px; font-size: 0.9rem;">
          <label><input type="radio" name="lyrics_lang" value="ja" <?php checked($state['lyrics_lang'] ?? '', 'ja'); ?>> 日本語メイン</label>
          <label><input type="radio" name="lyrics_lang" value="en" <?php checked($state['lyrics_lang'] ?? '', 'en'); ?>> 英語メイン</label>
          <label><input type="radio" name="lyrics_lang" value="mix" <?php checked($state['lyrics_lang'] ?? '', 'mix'); ?>> 日英ミックス</label>
          <label><input type="radio" name="lyrics_lang" value="none" <?php checked($state['lyrics_lang'] ?? '', 'none'); ?>> 歌詞なし（インスト）</label>
        </div>
      </div>

      <!-- 自由記入欄（SPECIAL_MESSAGE のときは「歌詞入力欄」として使用） -->
      <div class="form-group" style="margin-bottom: 16px;">
        <label id="detail-label" for="detail"
               style="display: block; font-weight: 600; margin-bottom: 4px;">
          自由記入欄（その他のご希望・イメージなど）
        </label>
          <textarea id="detail" name="detail" rows="4"
            placeholder="例）サビで盛り上がる感じにしたい／〇〇〇という言葉を入れて、など"
            style="width: 100%; padding: 8px 10px; border-radius: 8px; border: 1px solid #ccc; font-size: 0.9rem;"><?php
              echo esc_textarea($state['detail'] ?? '');
          ?></textarea>
      </div>

      <!-- 送信ボタン -->
      <div style="margin-top: 24px; display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
        <button type="submit"
                class="bubble"
                style="padding: 10px 20px; border-radius: 999px; border: none; cursor: pointer;
                       background: #df09aad8; color: #fff; font-weight: 600; font-size: 0.95rem;">
          この条件で曲を依頼する
        </button>
      </div>
    </form>
  </section>

  <!-- トップページへ戻るリンク -->
  <section style="margin-bottom: 32px;">
    <p class="bubble" style="margin-top: 8px; text-align: center;">
      <a href="/index" class="back-link"
         style="font-size: 0.8rem; text-decoration: none; color: #2e07db; display: inline-block;">
        🔙 トップページに戻る
      </a>
    </p>
  </section>
</main>

<?php get_footer(); ?>

