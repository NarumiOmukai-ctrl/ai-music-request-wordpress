<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php bloginfo('name'); ?></title>
  <?php wp_head(); ?>
  <style>
    /* スプラッシュ画面用 CSS */
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
    }

    /* 全体コンテナ（フェードアウト用） */
    .splash-container {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      background: linear-gradient(180deg, #fffafc 0%, #ffffff 40%, #ffffff 100%);
      transition: opacity 0.8s ease;
      opacity: 1;
      z-index: 9999;
      pointer-events: none;
    }

    .splash-container.fade-out {
      opacity: 0;
      pointer-events: none;
    }

    /* ロゴ：ラッパーが上下ゆらゆら、画像はふわっとフェードイン */
    .logo-wrapper {
      animation: bob 2.6s ease-in-out infinite;
    }

    .logo {
      width: 75%;
      max-width: 420px;
      opacity: 0;
      animation: fadeIn 1.8s ease-out forwards;
    }

    @keyframes bob {
      0%   { transform: translateY(6px); }
      50%  { transform: translateY(-6px); }
      100% { transform: translateY(6px); }
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.96); }
      to   { opacity: 1; transform: scale(1); }
    }

    /* 背景の音符たち：揺れながらフェードイン・フェードアウト */
    .note {
      position: absolute;
      bottom: 50%;
      opacity: 0;
      animation: fadeInOut 4s ease-in-out infinite;
      pointer-events: none;
      transform: translateY(50%);
    }

    .note span {
      display: block;
      animation: sway 2.7s ease-in-out infinite;
    }

    .note:nth-child(1) span  { animation-name: sway1; animation-duration: 2.3s; }
    .note:nth-child(2) span  { animation-name: sway2; animation-duration: 2.8s; }
    .note:nth-child(3) span  { animation-name: sway3; animation-duration: 2.1s; }
    .note:nth-child(4) span  { animation-name: sway4; animation-duration: 2.6s; }
    .note:nth-child(5) span  { animation-name: sway1; animation-duration: 2.4s; }
    .note:nth-child(6) span  { animation-name: sway3; animation-duration: 2.7s; }
    .note:nth-child(7) span  { animation-name: sway2; animation-duration: 2.2s; }
    .note:nth-child(8) span  { animation-name: sway4; animation-duration: 2.9s; }
    .note:nth-child(9) span  { animation-name: sway1; animation-duration: 2.5s; }
    .note:nth-child(10) span { animation-name: sway2; animation-duration: 2.35s; }
    .note:nth-child(11) span { animation-name: sway3; animation-duration: 2.65s; }
    .note:nth-child(12) span { animation-name: sway4; animation-duration: 2.45s; }

    /* 位置・色・サイズ・遅延をバラけさせる */
    .note:nth-child(1)  { left: 8%;  animation-delay: 0s;    animation-duration: 4.2s; }
    .note:nth-child(2)  { left: 18%; animation-delay: 0.3s;  animation-duration: 4.8s; }
    .note:nth-child(3)  { left: 26%; animation-delay: 0.6s;  animation-duration: 3.9s; }
    .note:nth-child(4)  { left: 34%; animation-delay: 0.9s;  animation-duration: 4.5s; }
    .note:nth-child(5)  { left: 45%; animation-delay: 1.2s;  animation-duration: 4.1s; }
    .note:nth-child(6)  { left: 56%; animation-delay: 1.0s;  animation-duration: 4.7s; }
    .note:nth-child(7)  { left: 64%; animation-delay: 0.6s;  animation-duration: 4.3s; }
    .note:nth-child(8)  { left: 72%; animation-delay: 1.0s;  animation-duration: 4.6s; }
    .note:nth-child(9)  { left: 80%; animation-delay: 0.2s;  animation-duration: 4.4s; }
    .note:nth-child(10) { left: 88%; animation-delay: 0.5s;  animation-duration: 3.95s; }
    .note:nth-child(11) { left: 94%; animation-delay: 0.8s;  animation-duration: 4.65s; }
    .note:nth-child(12) { left: 3%;  animation-delay: 1.1s;  animation-duration: 4.25s; }

    /* 色とサイズを少しランダム風に */
    .note:nth-child(1)  span { font-size: 1.4rem; color:#ff8bc7; }
    .note:nth-child(2)  span { font-size: 1.1rem; color:#ffb86c; }
    .note:nth-child(3)  span { font-size: 1.6rem; color:#9ad0ff; }
    .note:nth-child(4)  span { font-size: 1.2rem; color:#9be29f; }
    .note:nth-child(5)  span { font-size: 1.5rem; color:#ffa3d1; }
    .note:nth-child(6)  span { font-size: 1.3rem; color:#ffd76e; }
    .note:nth-child(7)  span { font-size: 1.2rem; color:#ff9fb5; }
    .note:nth-child(8)  span { font-size: 1.7rem; color:#8fd6ff; }
    .note:nth-child(9)  span { font-size: 1.1rem; color:#b4e47c; }
    .note:nth-child(10) span { font-size: 1.4rem; color:#ffc98a; }
    .note:nth-child(11) span { font-size: 1.3rem; color:#d89cff; }
    .note:nth-child(12) span { font-size: 1.2rem; color:#ff89cf; }

    @keyframes fadeInOut {
      0% {
        opacity: 0;
      }
      20% {
        opacity: 1;
      }
      80% {
        opacity: 1;
      }
      100% {
        opacity: 0;
      }
    }

    @keyframes sway {
      0%   { transform: translateX(0)    rotate(0deg);   }
      25%  { transform: translateX(12px) rotate(6deg);   }
      50%  { transform: translateX(0)    rotate(0deg);   }
      75%  { transform: translateX(-12px) rotate(-6deg); }
      100% { transform: translateX(0)    rotate(0deg);   }
    }

    @keyframes sway1 {
      0%   { transform: translateX(0)    rotate(0deg);   }
      25%  { transform: translateX(10px) rotate(5deg);   }
      50%  { transform: translateX(0)    rotate(0deg);   }
      75%  { transform: translateX(-10px) rotate(-5deg); }
      100% { transform: translateX(0)    rotate(0deg);   }
    }

    @keyframes sway2 {
      0%   { transform: translateX(0)    rotate(0deg);   }
      20%  { transform: translateX(14px) rotate(7deg);   }
      50%  { transform: translateX(0)    rotate(0deg);   }
      80%  { transform: translateX(-14px) rotate(-7deg); }
      100% { transform: translateX(0)    rotate(0deg);   }
    }

    @keyframes sway3 {
      0%   { transform: translateX(0)    rotate(0deg);   }
      30%  { transform: translateX(8px)  rotate(4deg);   }
      50%  { transform: translateX(0)    rotate(0deg);   }
      70%  { transform: translateX(-8px) rotate(-4deg);  }
      100% { transform: translateX(0)    rotate(0deg);   }
    }

    @keyframes sway4 {
      0%   { transform: translateX(0)    rotate(0deg);   }
      25%  { transform: translateX(-11px) rotate(-5.5deg); }
      50%  { transform: translateX(0)    rotate(0deg);   }
      75%  { transform: translateX(11px) rotate(5.5deg); }
      100% { transform: translateX(0)    rotate(0deg);   }
    }

    /* スマホ向けに少し縮小 */
    @media (max-width: 480px) {
      .logo {
        width: 82%;
        max-width: 320px;
      }
    }
  </style>
</head>

<body <?php body_class(); ?>>
<?php if (is_front_page()) : ?>

  <!-- スプラッシュ画面 -->
  <div class="splash-container" id="splash">
    <!-- 背景の音符たち -->
    <div class="note"><span>♪</span></div>
    <div class="note"><span>♬</span></div>
    <div class="note"><span>♪</span></div>
    <div class="note"><span>♩</span></div>
    <div class="note"><span>♫</span></div>
    <div class="note"><span>♪</span></div>
    <div class="note"><span>♬</span></div>
    <div class="note"><span>♪</span></div>
    <div class="note"><span>♫</span></div>
    <div class="note"><span>♩</span></div>
    <div class="note"><span>♪</span></div>
    <div class="note"><span>♬</span></div>

    <!-- ロゴ -->
    <div class="logo-wrapper">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/App-Name.png" alt="<?php bloginfo('name'); ?>" class="logo">
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const splash = document.getElementById('splash');
      const SHOW_TIME = 5000;   // 表示時間（5秒）
      const FADE_TIME = 800;    // フェードアウト時間

      // ローカルストレージで初回訪問かチェック
      if (!sessionStorage.getItem('splash-shown')) {
        // 初回訪問：スプラッシュを表示
        sessionStorage.setItem('splash-shown', 'true');

        setTimeout(() => {
          splash.classList.add('fade-out');

          // フェードアウトが終わったら隠す
          setTimeout(() => {
            splash.style.display = 'none';
          }, FADE_TIME);
        }, SHOW_TIME);
      } else {
        // 2回目以降：スプラッシュをすぐに隠す
        splash.style.display = 'none';
      }
    });
  </script>
<?php endif; ?>